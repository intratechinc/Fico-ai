import React from 'react';

const Map: React.FC = () => <></>;

export default Map;