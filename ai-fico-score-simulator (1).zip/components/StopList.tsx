import React from 'react';

const StopList: React.FC = () => <></>;

export default StopList;