import React from 'react';

const SuggestionOverlay: React.FC = () => <></>;

export default SuggestionOverlay;