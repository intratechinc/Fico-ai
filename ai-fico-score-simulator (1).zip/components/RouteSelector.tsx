import React from 'react';

const RouteSelector: React.FC = () => <></>;

export default RouteSelector;