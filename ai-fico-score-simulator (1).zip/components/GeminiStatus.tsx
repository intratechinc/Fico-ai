import React from 'react';

const GeminiStatus: React.FC = () => <></>;

export default GeminiStatus;